#ifndef __SYN6288_H
#define __SYN6288_H
//#include "usart.h"
#include "sys.h"


void SYN_FrameInfo(u8 Music, u8 *HZdata);
void YS_SYN_Set(u8 *Info_data);
//void USART1_SendString(u8 *DAT, u8 len);
#endif

